====================
Support and Issues
====================
 
Hi! 👋 It looks like you're looking for support or want to report an issue.
 
🚀 **We have moved to a dedicated support forum!**  
Please visit our `Hailo Community Forum <https://community.hailo.ai/>`_ to ask questions and report issues.
 
We no longer track issues in this GitHub repository. For any technical discussions, feature requests, or bug reports, please post in the community.
 
Thanks for your cooperation! 🎉
